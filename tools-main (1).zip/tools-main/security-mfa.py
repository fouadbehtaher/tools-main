def enable_mfa_for_key_management():
    print("مفعل التوثيق متعدد العوامل للمفاتيح.")
